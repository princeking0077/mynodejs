// Node.js Backend API Service
// Since the frontend is served by the same Node server in production, we use a relative path '/api'.
// In development, Vite proxys '/api' to 'http://localhost:3000/api' (check vite.config.js) or we can hardcode.

const API_BASE_URL = '/api';

export const api = {
    // Admin Login
    login: async (email, password) => {
        try {
            const response = await fetch(`${API_BASE_URL}/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || 'Login failed');
            return data;
        } catch (error) {
            console.error("Login Error:", error);
            throw error;
        }
    },

    // Verify Backend Status
    checkStatus: async () => {
        try {
            const response = await fetch(`${API_BASE_URL}/health`);
            return await response.json();
        } catch (error) {
            console.error("API Error", error);
            return { status: "error", message: "Could not connect to API" };
        }
    },

    // Get Content (for Students/Admin)
    getContent: async (subjectId) => {
        try {
            const response = await fetch(`${API_BASE_URL}/content?subject=${subjectId}`);
            if (!response.ok) return [];
            return await response.json();
        } catch (error) {
            console.error("Fetch Content Error", error);
            return [];
        }
    },

    // Get Global Stats
    getStats: async () => {
        try {
            const response = await fetch(`${API_BASE_URL}/content/stats`);
            if (!response.ok) return null;
            return await response.json();
        } catch (error) {
            console.error("Fetch Stats Error", error);
            return null;
        }
    },

    // Upload Content (for Admin) 
    uploadContent: async (formData) => {
        try {
            // Need to send token for auth
            const user = JSON.parse(localStorage.getItem('apex_user'));
            const token = user?.token;

            const response = await fetch(`${API_BASE_URL}/upload`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`
                    // Do NOT set Content-Type header for FormData, browser does it automatically with boundary
                },
                body: formData
            });
            const text = await response.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                console.error("Upload - Server returned non-JSON:", text);
                throw new Error(`Upload Failed: ${text.substring(0, 100)}...`);
            }
            return data;
        } catch (error) {
            console.error("Upload Error", error);
            throw error;
        }
    },

    // Save Topic (Create)
    saveTopic: async (topicData) => {
        try {
            const user = JSON.parse(localStorage.getItem('apex_user'));
            const response = await fetch(`${API_BASE_URL}/content`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${user?.token}`
                },
                body: JSON.stringify(topicData)
            });
            const text = await response.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                console.error("Server returned non-JSON:", text);
                throw new Error(`Server Error: ${text.substring(0, 100)}...`);
            }

            // Handle token expiry/invalid
            if (response.status === 403 || response.status === 401) {
                localStorage.removeItem('apex_user');
                throw new Error("Session expired. Please log out and log back in.");
            }

            if (!response.ok) throw new Error(data.message || "Failed to save");
            return data;
        } catch (error) {
            console.error("Save Topic Error", error);
            throw error;
        }
    },

    // Update Topic
    updateTopic: async (topicData) => {
        try {
            const user = JSON.parse(localStorage.getItem('apex_user'));
            const response = await fetch(`${API_BASE_URL}/content`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${user?.token}`
                },
                body: JSON.stringify(topicData)
            });
            const text = await response.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                console.error("Update - Server returned non-JSON:", text);
                throw new Error(`Update Failed: ${text.substring(0, 100)}...`);
            }

            // Handle token expiry/invalid
            if (response.status === 403 || response.status === 401) {
                localStorage.removeItem('apex_user');
                throw new Error("Session expired. Please log out and log back in.");
            }

            if (!response.ok) throw new Error(data.message || "Failed to update");
            return data;
        } catch (error) {
            console.error("Update Topic Error", error);
            throw error;
        }
    },

    // Search Content
    searchContent: async (query) => {
        try {
            const response = await fetch(`${API_BASE_URL}/content/search?q=${encodeURIComponent(query)}`);
            if (!response.ok) return [];
            return await response.json();
        } catch (error) {
            console.error("Search Error", error);
            return [];
        }
    },

    // Delete Topic
    deleteTopic: async (id) => {
        try {
            const user = JSON.parse(localStorage.getItem('apex_user'));
            const response = await fetch(`${API_BASE_URL}/content/${id}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${user?.token}`
                }
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || "Failed to delete");
            return data;
        } catch (error) {
            console.error("Delete Topic Error", error);
            throw error;
        }
    },

    // Global Settings
    getSettings: async () => {
        try {
            const user = JSON.parse(localStorage.getItem('apex_user'));
            const response = await fetch(`${API_BASE_URL}/settings`, {
                headers: {
                    'Authorization': `Bearer ${user?.token}`
                }
            });
            if (!response.ok) return {};
            return await response.json();
        } catch (error) {
            console.error("Get Settings Error", error);
            return {};
        }
    },

    getPublicSettings: async () => {
        try {
            const response = await fetch(`${API_BASE_URL}/settings/public`);
            if (!response.ok) return {};
            return await response.json();
        } catch (error) {
            console.error("Get Public Settings Error", error);
            return {};
        }
    },

    saveSettings: async (settings) => {
        try {
            const user = JSON.parse(localStorage.getItem('apex_user'));
            const response = await fetch(`${API_BASE_URL}/settings`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${user?.token}`
                },
                body: JSON.stringify(settings)
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || "Failed to save settings");
            return data;
        } catch (error) {
            console.error("Save Settings Error", error);
            throw error;
        }
    },

    // SEO Tools
    getQualityReport: async () => {
        try {
            const user = JSON.parse(localStorage.getItem('apex_user'));
            const response = await fetch(`${API_BASE_URL}/seo/quality-report`, {
                headers: { 'Authorization': `Bearer ${user?.token}` }
            });
            if (!response.ok) return null;
            return await response.json();
        } catch (error) {
            console.error(error);
            return null;
        }
    },

    regenerateLinks: async () => {
        try {
            const user = JSON.parse(localStorage.getItem('apex_user'));
            const response = await fetch(`${API_BASE_URL}/seo/regenerate-links`, {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${user?.token}` }
            });
            return await response.json();
        } catch (error) {
            console.error(error);
            throw error;
        }
    },

    invalidateSitemap: async (type = 'all') => {
        try {
            const user = JSON.parse(localStorage.getItem('apex_user'));
            const response = await fetch(`${API_BASE_URL}/seo/invalidate-sitemap`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${user?.token}`
                },
                body: JSON.stringify({ type })
            });
            return await response.json();
        } catch (error) {
            console.error(error);
            throw error;
        }
    }
};

