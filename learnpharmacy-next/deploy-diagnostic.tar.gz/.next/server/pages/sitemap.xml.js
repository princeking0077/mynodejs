"use strict";(()=>{var e={};e.id=164,e.ids=[164,660,888],e.modules={1323:(e,r)=>{Object.defineProperty(r,"l",{enumerable:!0,get:function(){return function e(r,t){return t in r?r[t]:"then"in r&&"function"==typeof r.then?r.then(r=>e(r,t)):"function"==typeof r&&"default"===t?r:void 0}}})},2159:(e,r,t)=>{t.a(e,async(e,n)=>{try{t.r(r),t.d(r,{config:()=>h,default:()=>p,getServerSideProps:()=>d,getStaticPaths:()=>y,getStaticProps:()=>g,reportWebVitals:()=>m,routeModule:()=>q,unstable_getServerProps:()=>P,unstable_getServerSideProps:()=>x,unstable_getStaticParams:()=>_,unstable_getStaticPaths:()=>S,unstable_getStaticProps:()=>f});var a=t(7093),o=t(5244),s=t(1323),i=t(582),l=t(5148),c=t(5745),u=e([l]);l=(u.then?(await u)():u)[0];let p=(0,s.l)(c,"default"),g=(0,s.l)(c,"getStaticProps"),y=(0,s.l)(c,"getStaticPaths"),d=(0,s.l)(c,"getServerSideProps"),h=(0,s.l)(c,"config"),m=(0,s.l)(c,"reportWebVitals"),f=(0,s.l)(c,"unstable_getStaticProps"),S=(0,s.l)(c,"unstable_getStaticPaths"),_=(0,s.l)(c,"unstable_getStaticParams"),P=(0,s.l)(c,"unstable_getServerProps"),x=(0,s.l)(c,"unstable_getServerSideProps"),q=new a.PagesRouteModule({definition:{kind:o.x.PAGES,page:"/sitemap.xml",pathname:"/sitemap.xml",bundlePath:"",filename:""},components:{App:l.default,Document:i.default},userland:c});n()}catch(e){n(e)}})},606:(e,r,t)=>{let n=t(2418),a=t(5315);t(5142).config({path:a.join(__dirname,".env")}),process.env.DB_HOST||t(5142).config({path:a.join(__dirname,"../.env")}),process.env.DB_USER||(console.error("CRITICAL ERROR: DB_USER is missing from environment variables!"),console.error("Current ENV keys:",Object.keys(process.env)));let o=n.createPool({host:process.env.DB_HOST||"127.0.0.1",user:process.env.DB_USER,password:process.env.DB_PASS,database:process.env.DB_NAME,waitForConnections:!0,connectionLimit:10,queueLimit:0});!("phase-production-build"===process.env.NEXT_PHASE||"phase-export"===process.env.NEXT_PHASE)&&process.env.DB_USER&&o.getConnection().then(e=>{console.log("DATABASE CONNECTED SUCCESSFULLY"),e.release()}).catch(e=>{console.error("DATABASE CONNECTION FAILED:",e.message),console.error("Check your DB_HOST, DB_USER, DB_PASS in environment variables.")}),e.exports=o},582:(e,r,t)=>{t.r(r),t.d(r,{default:()=>i});var n=t(997),a=t(6859),o=t.n(a);class s extends o(){static async getInitialProps(e){let r=await o().getInitialProps(e),n={};try{let e=t(606),[r]=await e.query("SELECT setting_key, setting_value FROM global_seo_settings LIMIT 50");r.forEach(e=>{n[e.setting_key]=e.setting_value})}catch(e){n={}}return{...r,seoSettings:n}}render(){let{seoSettings:e={}}=this.props,r=(e=>{if(!e||"string"!=typeof e)return null;let r=e.match(/client=(ca-pub-[0-9]+)/);return r?r[1]:null})(e.adsense_code||null),t=(e=>{if(!e||"string"!=typeof e)return null;let r=e.match(/content="([^"]+)"/);return r?r[1]:null})(e.google_search_console||null),o=e.google_analytics_id&&String(e.google_analytics_id).trim()||null;return(0,n.jsxs)(a.Html,{lang:"en",children:[(0,n.jsxs)(a.Head,{children:[n.jsx("meta",{charSet:"utf-8"}),n.jsx("link",{rel:"preconnect",href:"https://fonts.googleapis.com"}),n.jsx("link",{rel:"preconnect",href:"https://fonts.gstatic.com",crossOrigin:"anonymous"}),n.jsx("link",{href:"https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap",rel:"stylesheet"}),t?n.jsx("meta",{name:"google-site-verification",content:t}):null,o?(0,n.jsxs)(n.Fragment,{children:[n.jsx("script",{async:!0,src:`https://www.googletagmanager.com/gtag/js?id=${o}`}),n.jsx("script",{dangerouslySetInnerHTML:{__html:`window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${o}');`}})]}):null,r?n.jsx("script",{async:!0,src:`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${r}`,crossOrigin:"anonymous"}):null]}),(0,n.jsxs)("body",{children:[n.jsx(a.Main,{}),n.jsx(a.NextScript,{})]})]})}}let i=s},5745:(e,r,t)=>{function n(){return null}async function a({res:e}){try{let r=t(606),[n]=await r.query("SELECT title FROM subjects"),a=n.map(e=>({slug:e.title.toLowerCase().replace(/–/g,"-").replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"")})),[o]=await r.query("SELECT slug, created_at as updated_at FROM content"),s=o.map(e=>({slug:e.slug,updated_at:e.updated_at})),i=function(e,r){let t="https://learnpharmacy.in";return`<?xml version="1.0" encoding="UTF-8"?>
   <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
     <!-- Static Pages -->
     <url>
       <loc>${t}</loc>
       <changefreq>daily</changefreq>
       <priority>1.0</priority>
     </url>
     <url>
       <loc>${t}/bpharm-syllabus</loc>
       <changefreq>monthly</changefreq>
       <priority>0.9</priority>
     </url>
     <url>
       <loc>${t}/gpat-syllabus</loc>
       <changefreq>monthly</changefreq>
       <priority>0.9</priority>
     </url>
     <url>
       <loc>${t}/year/year-1</loc>
       <changefreq>weekly</changefreq>
       <priority>0.85</priority>
     </url>
     <url>
       <loc>${t}/year/year-2</loc>
       <changefreq>weekly</changefreq>
       <priority>0.85</priority>
     </url>
     <url>
       <loc>${t}/year/year-3</loc>
       <changefreq>weekly</changefreq>
       <priority>0.85</priority>
     </url>
     <url>
       <loc>${t}/year/year-4</loc>
       <changefreq>weekly</changefreq>
       <priority>0.85</priority>
     </url>
     <url>
       <loc>${t}/about</loc>
       <changefreq>monthly</changefreq>
       <priority>0.7</priority>
     </url>
     <url>
       <loc>${t}/contact</loc>
       <changefreq>monthly</changefreq>
       <priority>0.7</priority>
     </url>

     <!-- Dynamic Subject URLs -->
     ${e.map(({slug:e})=>`
       <url>
           <loc>${t}/subjects/${e}</loc>
           <changefreq>weekly</changefreq>
           <priority>0.9</priority>
       </url>
     `).join("")}
       
     <!-- Dynamic Article URLs -->
     ${r.map(({slug:e,updated_at:r})=>{let n=r?new Date(r).toISOString():new Date().toISOString();return`
       <url>
           <loc>${t}/articles/${e}</loc>
           <lastmod>${n}</lastmod>
           <changefreq>weekly</changefreq>
           <priority>0.8</priority>
       </url>
     `}).join("")}
   </urlset>
 `}(a,s);return e.setHeader("Content-Type","text/xml"),e.setHeader("Cache-Control","public, s-maxage=3600, stale-while-revalidate=86400"),e.write(i),e.end(),{props:{}}}catch(r){return console.error("Error generating sitemap:",r),e.statusCode=500,e.end(),{props:{}}}}t.r(r),t.d(r,{default:()=>n,getServerSideProps:()=>a})},5244:(e,r)=>{var t;Object.defineProperty(r,"x",{enumerable:!0,get:function(){return t}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(t||(t={}))},5142:e=>{e.exports=require("dotenv")},2418:e=>{e.exports=require("mysql2/promise")},2785:e=>{e.exports=require("next/dist/compiled/next-server/pages.runtime.prod.js")},968:e=>{e.exports=require("next/head")},6689:e=>{e.exports=require("react")},6405:e=>{e.exports=require("react-dom")},997:e=>{e.exports=require("react/jsx-runtime")},2048:e=>{e.exports=require("fs")},5315:e=>{e.exports=require("path")},6162:e=>{e.exports=require("stream")},1568:e=>{e.exports=require("zlib")},6197:e=>{e.exports=import("framer-motion")}};var r=require("../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),n=r.X(0,[443,760,859,148],()=>t(2159));module.exports=n})();