import { useState, useEffect } from 'react';
import AdminLayout from '../../components/AdminLayout';
import { Plus, Pencil, Trash2, ChevronRight, BookOpen, Layers, GraduationCap, X, Save } from 'lucide-react';

const API = process.env.NEXT_PUBLIC_API_URL || '';

export default function SubjectManager() {
    const [hierarchy, setHierarchy] = useState([]);
    const [loading, setLoading] = useState(true);
    const [msg, setMsg] = useState(null);
    const [showModal, setShowModal] = useState(null); // 'year', 'sem', 'sub'
    const [editingItem, setEditingItem] = useState(null);
    const [formData, setFormData] = useState({});

    const fetchHierarchy = async () => {
        setLoading(true);
        try {
            const r = await fetch(`${API}/api/subjects/hierarchy`, { credentials: 'include' });
            if (r.ok) setHierarchy(await r.json());
        } finally { setLoading(false); }
    };

    useEffect(() => { fetchHierarchy(); }, []);

    const handleSave = async () => {
        let endpoint = '';
        if (showModal === 'year') endpoint = '/api/subjects/years';
        else if (showModal === 'sem') endpoint = '/api/subjects/semesters';
        else if (showModal === 'sub') endpoint = '/api/subjects/subjects';

        try {
            const r = await fetch(`${API}${endpoint}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify(formData)
            });
            if (r.ok) {
                setMsg({ type: 'success', text: 'Saved successfully!' });
                setShowModal(null);
                fetchHierarchy();
            } else {
                const err = await r.json();
                setMsg({ type: 'error', text: err.message || 'Save failed' });
            }
        } catch (e) {
            setMsg({ type: 'error', text: e.message });
        }
    };

    const handleDelete = async (type, id) => {
        if (!confirm(`Delete this ${type}? This action cannot be undone.`)) return;
        let endpoint = '';
        if (type === 'subject') endpoint = `/api/subjects/subjects/${id}`;
        // Note: Year and Sem deletion not implemented in basic API yet for safety
        else return alert("Deletion for Years/Semesters is disabled to prevent accidental data loss.");

        const r = await fetch(`${API}${endpoint}`, { method: 'DELETE', credentials: 'include' });
        if (r.ok) {
            setMsg({ type: 'success', text: 'Deleted!' });
            fetchHierarchy();
        }
    };

    return (
        <AdminLayout title="Subject & Curriculum Manager">
            <div style={{ maxWidth: 900 }}>
                {msg && (
                    <div style={{ padding: '0.75rem 1rem', borderRadius: 10, marginBottom: '1.5rem', background: msg.type === 'success' ? 'rgba(16,185,129,0.1)' : 'rgba(239,68,68,0.1)', border: `1px solid ${msg.type === 'success' ? '#10b981' : '#ef4444'}40`, color: msg.type === 'success' ? '#10b981' : '#ef4444', display: 'flex', justifyContent: 'space-between' }}>
                        {msg.text} <X size={16} style={{ cursor: 'pointer' }} onClick={() => setMsg(null)} />
                    </div>
                )}

                <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '2rem' }}>
                    <button onClick={() => { setShowModal('year'); setFormData({ title: '', slug: '', position: 0 }); }} style={primaryBtn}>
                        <Plus size={16} /> Add Year/Category
                    </button>
                </div>

                {loading ? (
                    <div style={{ textAlign: 'center', padding: '4rem', color: 'rgba(255,255,255,0.3)' }}>Loading hierarchy…</div>
                ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
                        {hierarchy.map(year => (
                            <div key={year.id} style={yearCard}>
                                <div style={cardHeader}>
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                                        <GraduationCap size={20} color="#10b981" />
                                        <h3 style={{ margin: 0, fontSize: '1.1rem', color: 'white' }}>{year.title}</h3>
                                        <span style={badge}>{year.slug}</span>
                                    </div>
                                    <button onClick={() => { setShowModal('sem'); setFormData({ year_id: year.id, title: '', slug: '', position: 0 }); }} style={ghostBtn}>
                                        <Plus size={14} /> Add Semester
                                    </button>
                                </div>

                                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', padding: '1rem' }}>
                                    {year.semesters.map(sem => (
                                        <div key={sem.id} style={semSection}>
                                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
                                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'rgba(255,255,255,0.8)', fontWeight: 600, fontSize: '0.9rem' }}>
                                                    <Layers size={16} /> {sem.title}
                                                </div>
                                                <button onClick={() => { setShowModal('sub'); setFormData({ semester_id: sem.id, id: '', title: '', type: 'Theory', position: 0 }); }} style={miniBtn}>
                                                    <Plus size={12} /> Add Subject
                                                </button>
                                            </div>

                                            <div style={subjectGrid}>
                                                {sem.subjects.map(sub => (
                                                    <div key={sub.id} style={subjectItem}>
                                                        <div style={{ flex: 1 }}>
                                                            <div style={{ color: 'white', fontWeight: 500, fontSize: '0.85rem' }}>{sub.title}</div>
                                                            <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.7rem' }}>ID: {sub.id} · {sub.type}</div>
                                                        </div>
                                                        <button onClick={() => handleDelete('subject', sub.id)} style={delBtn}><Trash2 size={12} /></button>
                                                    </div>
                                                ))}
                                                {sem.subjects.length === 0 && <div style={{ color: 'rgba(255,255,255,0.2)', fontSize: '0.8rem', fontStyle: 'italic' }}>No subjects added yet.</div>}
                                            </div>
                                        </div>
                                    ))}
                                    {year.semesters.length === 0 && <div style={{ textAlign: 'center', padding: '1rem', color: 'rgba(255,255,255,0.2)', fontSize: '0.85rem' }}>No semesters found for this category.</div>}
                                </div>
                            </div>
                        ))}
                    </div>
                )}

                {/* Modals */}
                {showModal && (
                    <div style={modalOverlay}>
                        <div style={modalContent}>
                            <h2 style={{ color: 'white', marginBottom: '1.5rem', fontSize: '1.25rem' }}>
                                Add {showModal === 'year' ? 'Year' : showModal === 'sem' ? 'Semester' : 'Subject'}
                            </h2>

                            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                                {showModal === 'sub' && (
                                    <div>
                                        <label style={labelStyle}>Subject ID (Code) *</label>
                                        <input value={formData.id} onChange={e => setFormData({ ...formData, id: e.target.value })} style={inputStyle} placeholder="e.g. bp101t" />
                                    </div>
                                )}
                                <div>
                                    <label style={labelStyle}>Title *</label>
                                    <input value={formData.title} onChange={e => setFormData({ ...formData, title: e.target.value })} style={inputStyle} placeholder="Display Name" />
                                </div>
                                {showModal !== 'sub' && (
                                    <div>
                                        <label style={labelStyle}>Slug *</label>
                                        <input value={formData.slug} onChange={e => setFormData({ ...formData, slug: e.target.value })} style={inputStyle} placeholder="URL-safe name" />
                                    </div>
                                )}
                                {showModal === 'sub' && (
                                    <div>
                                        <label style={labelStyle}>Type</label>
                                        <select value={formData.type} onChange={e => setFormData({ ...formData, type: e.target.value })} style={inputStyle}>
                                            <option value="Theory">Theory</option>
                                            <option value="Practical">Practical</option>
                                            <option value="Theory & Practical">Theory & Practical</option>
                                        </select>
                                    </div>
                                )}
                                <div>
                                    <label style={labelStyle}>Position</label>
                                    <input type="number" value={formData.position} onChange={e => setFormData({ ...formData, position: e.target.value })} style={inputStyle} />
                                </div>
                            </div>

                            <div style={{ display: 'flex', gap: '1rem', justifyContent: 'flex-end', marginTop: '2rem' }}>
                                <button onClick={() => setShowModal(null)} style={ghostBtn}>Cancel</button>
                                <button onClick={handleSave} style={primaryBtn}><Save size={16} /> Save</button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </AdminLayout>
    );
}

// Styles
const yearCard = { background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 16, overflow: 'hidden' };
const cardHeader = { padding: '1.25rem', borderBottom: '1px solid rgba(255,255,255,0.06)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: 'rgba(255,255,255,0.02)' };
const semSection = { background: 'rgba(0,0,0,0.2)', padding: '1rem', borderRadius: 12, borderLeft: '3px solid #3b82f6' };
const subjectGrid = { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: '0.75rem' };
const subjectItem = { display: 'flex', alignItems: 'center', padding: '0.75rem', background: 'rgba(255,255,255,0.03)', borderRadius: 8, border: '1px solid rgba(255,255,255,0.05)' };
const badge = { fontSize: '0.7rem', padding: '0.2rem 0.5rem', borderRadius: 20, background: 'rgba(16,185,129,0.1)', color: '#10b981', fontWeight: 600, textTransform: 'uppercase' };
const inputStyle = { width: '100%', padding: '0.75rem', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, color: 'white', outline: 'none' };
const labelStyle = { display: 'block', fontSize: '0.75rem', color: 'rgba(255,255,255,0.5)', marginBottom: '0.4rem', fontWeight: 600, textTransform: 'uppercase' };
const primaryBtn = { display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.75rem 1.25rem', background: 'linear-gradient(135deg, #10b981, #3b82f6)', color: 'white', border: 'none', borderRadius: 10, cursor: 'pointer', fontWeight: 700, fontSize: '0.85rem' };
const ghostBtn = { padding: '0.75rem 1.25rem', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, color: 'white', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.85rem' };
const miniBtn = { padding: '0.4rem 0.6rem', background: 'rgba(59,130,246,0.1)', border: '1px solid rgba(59,130,246,0.2)', borderRadius: 6, color: '#3b82f6', cursor: 'pointer', fontSize: '0.7rem', display: 'flex', alignItems: 'center', gap: '0.3rem', fontWeight: 600 };
const delBtn = { padding: '0.4rem', color: '#ef4444', background: 'none', border: 'none', cursor: 'pointer', opacity: 0.6 };
const modalOverlay = { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)', zIndex: 300, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' };
const modalContent = { background: '#0d0d1f', border: '1px solid rgba(255,255,255,0.1)', padding: '2rem', borderRadius: 20, width: '100%', maxWidth: 450 };
